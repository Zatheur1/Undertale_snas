Undertale Naming Screen Resource
--------------------------------------

Naming screen input example from the game Undertale that can be used in your games.

**Engine:** GameMaker

### Gif:

![Typing out my name](https://i.gyazo.com/ca11f524ede8b7f3f8967e7ecf78c61f.gif)

I want to say "thank you" to [Harry Wakamatsu](https://twitter.com/JapanYoshiLOL) for [Determination: A better Undertale font](https://www.behance.net/gallery/31268855/Determination-Better-Undertale-Font). I used and included their `DMT-Sans.otf` font in the download to install while using this asset.
